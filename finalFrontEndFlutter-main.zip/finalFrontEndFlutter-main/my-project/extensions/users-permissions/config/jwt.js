module.exports = {
  jwtSecret: process.env.JWT_SECRET || '0231b7ca-10ea-4c64-a1ea-ed14cab1327b'
};