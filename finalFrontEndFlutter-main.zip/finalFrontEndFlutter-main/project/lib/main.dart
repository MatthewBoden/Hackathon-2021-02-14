import 'package:flutter/material.dart';
import 'package:project/UI/profile_page.dart';
import 'UI/assignments_page.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter App',
      theme: ThemeData(
        primarySwatch: Colors.red,
      ),
      home: MyHomePage(title: 'Productivity Tutor'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({Key key, this.title}) : super(key: key);
  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      color: Colors.white,
      home: DefaultTabController(
        length: 2,
        child: new Scaffold(
          body: Stack(children: <Widget>[
            TabBarView(
              children: [AssignmentsPage(), GpaCalculator()],
            ),
          ]),
          appBar: AppBar(
            title: new TabBar(
              tabs: [
                Tab(
                  text: ('Assigments'),
                  icon: new Icon(Icons.star),
                ),
                Tab(
                  text: ('Exam Calculator'),
                  icon: new Icon(
                    Icons.calculate,
                  ),
                ),
              ],
              labelColor: Colors.white,
              unselectedLabelColor: Colors.black,
              indicatorSize: TabBarIndicatorSize.label,
              indicatorPadding: EdgeInsets.all(5.0),
              indicatorColor: Colors.white,
            ),
            backgroundColor: Colors.red[600],
          ),
        ),
      ),
    );
  }
}
